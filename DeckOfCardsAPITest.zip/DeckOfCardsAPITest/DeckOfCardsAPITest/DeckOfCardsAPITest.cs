﻿using RestSharp;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace DeckOfCardsAPITest
{
    [TestFixture]
    public class DeckOfCardsAPITest
    {
        [Test]
        public void apiTest1()
        {
            var restClient = new RestClient("https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1");
            
            var restRequest = new RestRequest(Method.GET);
            var response = restClient.Execute<DeckOfCards>(restRequest);
            var data = response.Data;

            Assert.IsTrue(data.success);
            Assert.IsTrue(data.remaining == "52");
        }

        [Test]
        public void apiTest2()
        {
            var restClient = new RestClient("https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1");

            var restRequest = new RestRequest(Method.GET);
            restRequest.AddParameter("jokers_enabled", "true");
            var response = restClient.Execute<DeckOfCards>(restRequest);
            var data = response.Data;

            Assert.IsTrue(data.success);
            Assert.IsTrue(data.remaining == "54");
        }

        [Test]
        public void apiTest3()
        {
            verifyCardDraw("2", "50");
            verifyCardDraw("5", "47");
            verifyCardDraw("0", "52");
            verifyCardDraw("-1", "1");
            verifyCardDraw("-2", "2");
        }

        public string getNewDeckId()
        {
            var restClient = new RestClient("https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1");

            var restRequest = new RestRequest(Method.GET);
            var response = restClient.Execute<DeckOfCards>(restRequest);
            var data = response.Data;

            return data.deck_id;
        }

        public void verifyCardDraw(string cardNum, string expRemaining)
        {
            var restClient = new RestClient("https://deckofcardsapi.com/api/deck/new/draw/?count=" + cardNum);
            var restRequest = new RestRequest(Method.GET);
            var response = restClient.Execute<DeckOfCards>(restRequest);
            var data = response.Data;

            Assert.IsTrue(data.success);
            Assert.IsTrue(data.remaining == expRemaining);
        }

        public class DeckOfCards
        {
            public bool success { get; set; }
            public string deck_id { get; set; }
            public bool shuffled { get; set; }
            public string remaining { get; set; }
        }
    }
}
